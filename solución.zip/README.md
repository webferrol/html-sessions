## Examen de Unidad Formativa

## Fuente Cascadia Code

Bájate el __zip__ de [https://github.com/microsoft/cascadia-code/releases](https://github.com/microsoft/cascadia-code/releases)

De las fuentes estáticas utilizar:

1. Para el __body__ CascadiaCode-Regular.woff2
2. Para los __encabezamientos__ CascadiaCode-Bold.woff2
3. Poner la fuente alternativa de extensión __ttf__ en caso de que el __user agent__ no sporte la extensión _woff2_


## Correciones

Cada pregunta vale 0.5 puntos sumando un total de 10

### Formulario

1. [] El método de envío es por la URL (__GET__)
2. [] El formulario puede ser enviado
3. [] Los campos del formulario llegan a un servidor
4. [] Los campos obligatorios __SON OBLIGATORIOS__
5. [] Los atributos __type__ de los controles de formulario __correo electrónico__, __teléfono__, __contraseña__ no son de tipo texto.
6. [] Placeholder o marcadores de posición
7. [] Opciones del selector o combo "País": China, India, United States, Indonesia, Brazil
8. [] El formulario se puede reiniciar

### Accesibilidad

Recuerta que prima la __estructura del contenido__ sobre la __presentación__. NO INTENTES EN EL HTML QUE EL FORMULARIO TE QUEDE COMO EN LA CAPTURA ESO FORMA PARTE DEL DISEÑO POSTERIOR.

9. [] Etiquetas label enlazadas con su respectivo __control de formulario__
10. [] Secciones y agrupaciones de los __controles de formulario__

Recuerda que tienes en los __devtools__ una herramienta para ver cómo de accesible es tu documento __HTML__. Ejemplo:

![Accisibilidad](./assets/accesibilty.jpg)

### Fuente

11. [] Fuente Cascadia de formato __woff2__ visible en el navegador
12. [] Fuente Cascadia alternativa de formato __ttf__ visible en el navegador

### Presentación

13. [] Diseño en columnas
14. [] Enlace de color naranja
15. [] Avisos en rojo
16. [] Máxima anchura de la página 800px
17. [] Todo el contenido estará centrado
18. [] Border de los controles de formulario de 1px
19. [] Limpiar estilos de fieldset y legend

### Validaciones

20. [] Pasa la validación W3C